<header class="navigation d-flex align-items-center justify-content-between container">
    <h2 class="fw-semibold">
        Historia Meze Grill<span class="text-danger">.</span>
    </h2>
    <nav>
        <a href="index.php#home">Beranda</a>
        <a href="index.php#paket">Paket Reservasi</a>
        <a class="btn btn-danger text-white" href="reservasi.php">Reservasi</a>
    </nav>
</header>